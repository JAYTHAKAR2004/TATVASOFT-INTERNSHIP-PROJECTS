Day 7 : User Retrieval
• Data retrieval using joins in the LINQ Query, Sorting, filtering and paging
• Hands-on: Data retrieval, data filtration, insertion, update, and deletion.


![operation](https://github.com/neel1112/Tatvasoft_Internship_2025/blob/main/Day%207/BookApi/operation.jpg)


