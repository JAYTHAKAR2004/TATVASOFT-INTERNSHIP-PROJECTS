Day 5 : Understand Authentication and Authorization<br>
    • Explore authentication and authorization concepts and implementation in the project.<br>
    • Hands-on: Understand and implement project authorization (Virtual Community Support).

 ### CROME RUNNING PREVIEW

![HOME](https://github.com/neel1112/Tatvasoft_Internship_2025/blob/main/Day%205/userdatabse.jpg)

![HOME](https://github.com/neel1112/Tatvasoft_Internship_2025/blob/main/Day%205/userdatabase2.jpg)
