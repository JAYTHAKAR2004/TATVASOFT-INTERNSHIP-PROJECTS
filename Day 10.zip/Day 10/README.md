Day 10 : Mission Skill CRUD
• Begin CRUD operations on the mission Skill table (Retrieve and Insert).
• Continued CRUD operations on mission Skill records (Update and Delete).
• Hands-on: Data retrieval, data filtration, insertion, update, and deletion
