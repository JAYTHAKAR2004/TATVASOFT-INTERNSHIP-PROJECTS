﻿namespace BooksApi.Models
{
    public static class UserRole
    {
        public const string Admin = "admin";
        public const string Manager = "manager";
        public const string User = "user";
    }
}