Day 6 : Role based Authorization (Admin and User roles)
• Hands on authentication concepts, Role-Based Access Control, and Access Control Lists (ACLs).
• Hands-on: Login Page. Learned and implemented role-based access control.


![LOGIN](https://github.com/neel1112/Tatvasoft_Internship_2025/blob/main/Day%206/login%20(1).jpeg)

![REGISTER](https://github.com/neel1112/Tatvasoft_Internship_2025/blob/main/Day%206/register.jpeg)
